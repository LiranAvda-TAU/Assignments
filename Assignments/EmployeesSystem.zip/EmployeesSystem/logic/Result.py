from typing import NamedTuple


class Result(NamedTuple):
    success: bool
    error: str
