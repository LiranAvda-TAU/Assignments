from typing import NamedTuple


class FieldName(NamedTuple):
    employee_id: str
    first_name: str
    last_name: str
    date_of_birth: str

